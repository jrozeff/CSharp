﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Rozeff_Jonathan_HW7.DAL;
  
namespace Rozeff_Jonathan_HW7.Utilities
{
    public static class GenerateShowingNumber
    {
        public static int GetNextShowingNumber(AppDbContext _context)
        {
            int intMaxShowingNumber;  //The current maximum course number
            int intNextShowingNumber;  //The course number for the next class 

            if (_context.Showings.Count() == 0)
            {
                intMaxShowingNumber = 5000; //Showing numbers start at 5001
            }
            else
            {
                intMaxShowingNumber = _context.Showings.Max(s => s.ShowingNumber); //this is the highest number in the database right now
            }

            //Add one to the current max to find the next one 
            intNextShowingNumber = intMaxShowingNumber + 1;

            //Return the value
            return intNextShowingNumber;
        }
    }
}
