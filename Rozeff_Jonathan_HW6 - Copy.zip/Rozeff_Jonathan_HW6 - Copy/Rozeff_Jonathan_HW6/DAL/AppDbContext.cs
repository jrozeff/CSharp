﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Rozeff_Jonathan_HW7.Models;

namespace Rozeff_Jonathan_HW7.DAL
{
    //NOTE: This class definition references the user class for this project.  
    //If your User class is called something other than AppUser, you will need
    //to change it in the line below
    public class AppDbContext : IdentityDbContext<AppUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        //IMPORTANT: Do NOT add DbSets for your ViewModel classes - they are not stored in your database
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Showing> Showings { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<MovieShowing> MovieShowings { get; set; }

        //Also, remember that Identity will add a DbSet for your User class.  It will be called Users.  
        //If you add another DbSet for users, you WILL get an error

    }
}
