﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Rozeff_Jonathan_HW7.Models
{
    public class OrderDetail
    {
        public int OrderDetailID { get; set; }

        [Required(ErrorMessage = "Quantity must be specified")]
        [Display(Name= "Quantity")]
        [Range(1, 100, ErrorMessage = "Quantity should be between 1 and 100")]
        public int Quantity { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Product Price")]
        public decimal ProductPrice { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Extended Price")]
        public decimal ExtendedPrice { get; set; }
        
        public Order Order { get; set; }
        public Showing Showing { get; set; }
       

    }
}
