﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace Rozeff_Jonathan_HW7.Models
{
    public class MovieShowing
    {
        public int MovieShowingID { get; set; }

        public Movie Movie { get; set; }
        public Showing Showing { get; set; }
    }
}
