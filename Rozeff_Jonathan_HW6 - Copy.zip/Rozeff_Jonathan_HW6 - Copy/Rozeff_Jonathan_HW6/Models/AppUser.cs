﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using Rozeff_Jonathan_HW7.Controllers;

namespace Rozeff_Jonathan_HW7.Models
{
    public class AppUser : IdentityUser
    {
        //Identity creates several of the important ones for you
        //e.g. = Email, Phone Number, UserID

        [Required(ErrorMessage = "First name is required.")]
        [Display(Name = "First Name")]
        public String FirstName { get; set; }
        
        [Required(ErrorMessage = "Last name is required")]
        [Display(Name = "Last Name")]
        public String LastName { get; set; }

        public List<Order> Orders { get; set; }

    }
}
