﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Rozeff_Jonathan_HW7.DAL;
using Rozeff_Jonathan_HW7.Models;

namespace Rozeff_Jonathan_HW7.Controllers
{
    public class OrderDetailsController : Controller
    {
        private readonly AppDbContext _context;

        public OrderDetailsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: OrderDetails
        //Index method is modified to include a parameter for the order number
        //This parameter will help us limit the order details to only those 
        //associated with a particular order
        public IActionResult Index(int orderId)
        {
            List<OrderDetail> ods = _context.OrderDetails
                .Include(s => s.Showing)
                .Where(o => o.Order.OrderID == orderId).ToList();
            return View(ods);
        }

        // GET: OrderDetails/Create
        //This action has been modified to include a order id so that we 
        //will know which order to associate the order detail with
        public IActionResult Create(int orderId)
        {
            OrderDetail od = new OrderDetail();
            od.Order = _context.Orders.Find(orderId);
            ViewBag.AllShowings = GetAllShowings();

            //Pass the newly created order detail to the view 
            return View(od);
        }

        // POST: OrderDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OrderDetailID,Quantity,ProductPrice, Order")] OrderDetail orderDetail, int SelectedShowing)
        {
            //Find the correct Showing
            Showing showing = _context.Showings.Find(SelectedShowing);
            orderDetail.Showing = showing;

            //Find the correct Order
            Order ord = _context.Orders.Find(orderDetail.Order.OrderID);
            orderDetail.Order = ord;

            //Set the order detail price equal to the showing price 
            orderDetail.ProductPrice = showing.Price;

            //Calculate the total price 
            orderDetail.ExtendedPrice = orderDetail.ProductPrice * orderDetail.Quantity;


            if (ModelState.IsValid)
            {
                _context.Add(orderDetail);
                await _context.SaveChangesAsync();

                //Modify the redirect action to take you to the order details page
                return RedirectToAction("Details", "Orders", new { id = orderDetail.Order.OrderID });
            }
            //Re-populate the ViewBag in case the data is not valid 
            ViewBag.AllShowings = GetAllShowings();
            return View(orderDetail);
        }

        // GET: OrderDetails/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            OrderDetail orderDetail = _context.OrderDetails
                .Include(s => s.Showing)
                .Include(o => o.Order)
                .FirstOrDefault(od => od.OrderDetailID == id);

            if (orderDetail == null)
            {
                return NotFound();
            }
            return View(orderDetail);
        }

        // POST: OrderDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind("OrderDetailID,Quantity,ProductPrice, ExtendedPrice")] OrderDetail orderDetail)
        {
            //Find the existing order detail in the database 
            //include both order and showing
            OrderDetail dbOD = _context.OrderDetails
                .Include(od => od.Showing)
                .Include(od => od.Order)
                .FirstOrDefault(o => o.OrderDetailID == orderDetail.OrderDetailID);

            //Update the scalar properties 
            dbOD.OrderDetailID = orderDetail.OrderDetailID;
            dbOD.Quantity = orderDetail.Quantity;
            dbOD.ProductPrice = orderDetail.ProductPrice;
            dbOD.ExtendedPrice = dbOD.Quantity * dbOD.ProductPrice;

            //Save changes
            if (ModelState.IsValid)
            {
                _context.Update(dbOD);
                _context.SaveChanges();

                //Redirect to Orders/Details
                return RedirectToAction("Details", "Orders", new { id = dbOD.Order.OrderID });
            }

            return View(dbOD);
        }

        // GET: OrderDetails/Delete/5
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            OrderDetail orderDetail = await _context.OrderDetails 
                .Include(o => o.Order)
                .FirstOrDefaultAsync(m => m.OrderDetailID == id);
            if (orderDetail == null)
            {
                return NotFound();
            }

            return View(orderDetail);
        }

        // POST: OrderDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Manager")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            //Update the query to include registration so you can redirect to 
            //the correct order page 
            OrderDetail orderDetail = _context.OrderDetails
                .Include(ord => ord.Order)
                .FirstOrDefault(o => o.OrderDetailID == id);
            Order or = orderDetail.Order;
            _context.OrderDetails.Remove(orderDetail);
            _context.SaveChanges();

            //Update this redirect statement to send user back to (order) details
            return RedirectToAction("Details", "Orders", new { id = or.OrderID });
        }

        private bool OrderDetailExists(int id)
        {
            return _context.OrderDetails.Any(e => e.OrderDetailID == id);
        }

        //Method to create the select list for the showings drop-down
        private SelectList GetAllShowings()
        {
            //Get a list of all showings from the database 
            List<Showing> AllShowings = _context.Showings.ToList();

            //Convert this to a select list 
            //note that ShowingID and Title are the names of fields in the Showing model class
            SelectList showings = new SelectList(AllShowings, "ShowingID", "Title");

            //return the SelectList
            return showings;

        }

    }
}
