﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Rozeff_Jonathan_HW4.Models
{ 
    public enum MovieRating {G,PG,PG13,R};

    public class Movie
    {
        [Required(ErrorMessage = "Movie ID is required")]
        [Display(Name = "Movie ID")]
        public int MovieID { get; set; }

        [Required(ErrorMessage = "Movie title is required")]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone Number is required")]
        [DataType(DataType.PhoneNumber)]
        [Display(Name = "Phone Number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Release date is required")]
        [DataType(DataType.Date)]
        [Display(Name = "Release Date")]
        public DateTime ReleaseDate { get; set; }

        [Required(ErrorMessage = "Rating is required")]
        [Display(Name = "Rating")]
        public MovieRating Rating { get; set; }

        [Required(ErrorMessage = "Special Release is required")]
        [Display(Name = "Special Release")]
        public bool SpecialRelease { get; set; }

        [Display(Name = "Notes")]
        public string Notes { get; set; }
    }


}