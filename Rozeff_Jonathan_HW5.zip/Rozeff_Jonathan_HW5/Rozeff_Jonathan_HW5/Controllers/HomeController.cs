﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Rozeff_Jonathan_HW5.DAL;
using Rozeff_Jonathan_HW5.Models;

namespace Rozeff_Jonathan_HW5.Controllers
{
    public enum SortOrder { LessThan, GreaterThan }

    public class HomeController : Controller
    {
        private AppDbContext _db;
        public HomeController(AppDbContext context)
        {
            _db = context;
        }


        public ActionResult DetailedSearch()
        {
            ViewBag.AllGenres = GetAllGenres();
            return View();
        }


        public ActionResult Index(String SearchString)
        {
            var query = from b in _db.Books
                        select b;

            if (String.IsNullOrEmpty(SearchString)) 
            {
                ViewBag.AllBookCount = _db.Books.Count();  
                ViewBag.SelectedBookCount = _db.Books.Count();
                List<Book> SelectedBooks = query.Include(b => b.Genre).ToList();
                return View(SelectedBooks.OrderByDescending(b => b.Price));
            }
            else 
            {
                query = query.Where(b => b.Author.Contains(SearchString) || b.Title.Contains(SearchString));

                List<Book> SelectedBooks = query.Include(b => b.Genre).ToList();
                ViewBag.AllBookCount = _db.Books.Count();  
                ViewBag.SelectedBookCount = SelectedBooks.Count();  
                return View(SelectedBooks.OrderByDescending(b => b.Price));
            }
        }


        public ActionResult DisplaySearchResults(String SearchString, String SearchDescriptionString, int SelectedGenre,
            String SearchPrice, SortOrder SelectedSortOrder, DateTime? ReleasedAfterDate)
        {
            var query = from b in _db.Books
                        select b;

            //SearchString query
            if (SearchString != null && SearchString != "")
            {
                query = query.Where(b => b.Author.Contains(SearchString) || b.Title.Contains(SearchString));      
            }

            //DescriptionString query 
            if (SearchDescriptionString != null && SearchDescriptionString != "")
            {
                query = query.Where(b => b.Description.Contains(SearchDescriptionString));
            }

            //SelectedGenre query
            if (SelectedGenre == 0)
            {
                ViewBag.Nothing = 0;
            }
            else
            {
                query = query.Where(b => b.Genre.GenreID == SelectedGenre);
            }

            //SearchPrice query
            if (SearchPrice != null && SearchPrice != "")
            {
                Decimal decPrice;
                try
                {
                    decPrice = Convert.ToDecimal(SearchPrice);
                    if (SelectedSortOrder == SortOrder.GreaterThan)
                    {
                        query = query.Where(b => b.Price >= decPrice);
                    }
                    else
                    {
                        query = query.Where(b => b.Price <= decPrice);
                    }
                }
                catch
                {
                    ViewBag.Message = SearchPrice + "is not a valid number. Please try again.";
                    ViewBag.AllGenres = GetAllGenres();
                }              
            }

            //ReleaseAfterDate query
            if (ReleasedAfterDate != null)
            {
                DateTime datReleasedAfter = ReleasedAfterDate ?? new DateTime(1900, 1, 1);
                query = query.Where(b => b.ReleaseDate > datReleasedAfter);
            }

            //List object with Include statement to get the navigational data
            List<Book> SelectedBooks = query.Include(b => b.Genre).ToList();
            SelectedBooks = _db.Books.Include(b => b.Genre).ToList();
            SelectedBooks = query.ToList();

            //Adds TotalBookCount and SelectedBookCount to ViewBag
            ViewBag.AllBookCount = _db.Books.Count();
            ViewBag.SelectedBookCount = SelectedBooks.Count();

            return View("Index", SelectedBooks.OrderByDescending(b => b.Price));

        }


        public SelectList GetAllGenres()
        {
            List<Genre> Genres = _db.Genres.ToList();

            Genre SelectNone = new Genre() { GenreID = 0, GenreName = "All Genres" };
            Genres.Add(SelectNone);

            SelectList AllGenres = new SelectList(Genres.OrderBy(b => b.GenreID), "GenreID", "GenreName");

            return AllGenres;
        }




        public ActionResult Details(int? id)
        {
            if (id == null)  //BookID not specified
            {
                return View("Error", new String[] { "BookID not specified - which book do you want to view?" });
            }

            Book book = _db.Books.Include(b => b.Genre).FirstOrDefault(b => b.BookID == id);

            if (book == null)  //Book does not exist in database
            {
                return View("Error", new String[] { "Book not found in database" });
            }

            //If code gets this far, all is well
            return View(book);
        }

    }

}
