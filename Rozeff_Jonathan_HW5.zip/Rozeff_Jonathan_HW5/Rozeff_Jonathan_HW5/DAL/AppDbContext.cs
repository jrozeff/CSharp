﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Rozeff_Jonathan_HW5.Models;
using Microsoft.EntityFrameworkCore;

namespace Rozeff_Jonathan_HW5.DAL
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

        public DbSet<Book> Books { get; set; }

        public DbSet<Genre> Genres { get; set; }
    }
}
