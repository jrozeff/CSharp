﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Rozeff_Jonathan_HW6.Models;
using Microsoft.EntityFrameworkCore;

namespace Rozeff_Jonathan_HW6.DAL
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Showing> Showings { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<MovieShowing> MovieShowings { get; set; } 



    }
}
