﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Rozeff_Jonathan_HW6.DAL;

namespace Rozeff_Jonathan_HW6.Utilities
{
    public class GenerateNextOrderNumber
    {
        public static int GetNextOrderNumber(AppDbContext _context)
        {
            int intMaxOrderNumber; //the current maximum course number
            int intNextOrderNumber; //the course number for the next class

            if (_context.Orders.Count() == 0) //there are no registrations in the database yet
            {
                intMaxOrderNumber = 10000; //registration numbers start at 10001
            }
            else
            {
                intMaxOrderNumber = _context.Orders.Max(c => c.OrderNumber); //this is the highest number in the database right now
            }

            //add one to the current max to find the next one
            intNextOrderNumber = intMaxOrderNumber + 1;

            //return the value
            return intNextOrderNumber;
        }
    }
}
