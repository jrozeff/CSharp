﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Rozeff_Jonathan_HW6.Models
{
    public class Order
    {
        private const decimal SALES_TAX = 0.0825M;

        [Display(Name = "Order ID")]
        public int OrderID { get; set; }

        [Display(Name = "Order Number")]
        public int OrderNumber { get; set; }

        [Required(ErrorMessage = "Order Date is required")]
        [Display(Name = "Order Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyy}")]
        public DateTime OrderDate { get; set; }

        [Display(Name = "Order Notes")]
        public string OrderNotes { get; set; }

        public List<OrderDetail> OrderDetails { get; set; }

        [Display(Name = "Order Subtotal")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal OrderSubtotal
        {
            get { return OrderDetails.Sum(rd => rd.ExtendedPrice); }
        }

        [Display(Name = "Order Tax")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal OrderTax
        {
            get { return (OrderSubtotal * SALES_TAX); }
        }

        [Display(Name = "Order Total")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal OrderTotal
        {
            get { return (OrderSubtotal + OrderTax); }
        }

        public Order()
        {
            if (OrderDetails == null)
            {
                OrderDetails = new List<OrderDetail>();
            }
        }
    }
}
