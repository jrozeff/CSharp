﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace Rozeff_Jonathan_HW6.Models
{
    public class Showing
    {
        public int ShowingID { get; set; }

        [Display(Name = "Showing Number")]
        public int ShowingNumber { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Showtime is required")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy hh:mm tt}")]
        [Display(Name = "Showtime")]
        public DateTime Showtime { get; set; }

        [Required(ErrorMessage = "Price is required")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Price")]
        public decimal Price { get; set; }

        public List<MovieShowing> MovieShowings { get; set; }
        public List<OrderDetail> OrderDetails { get; set; }

        public Showing() 
        {
            if (MovieShowings == null)
            {
                MovieShowings = new List<MovieShowing>(); 
            }

            if (OrderDetails == null)
            {
                OrderDetails = new List<OrderDetail>();
            }
        }

    }
}
