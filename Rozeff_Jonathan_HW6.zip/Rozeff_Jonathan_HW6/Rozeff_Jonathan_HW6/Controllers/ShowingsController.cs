﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Rozeff_Jonathan_HW6.DAL;
using Rozeff_Jonathan_HW6.Models;

namespace Rozeff_Jonathan_HW6.Controllers
{
    public class ShowingsController : Controller
    {
        private readonly AppDbContext _context;

        public ShowingsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Showings
        public async Task<IActionResult> Index()
        {
            return View(await _context.Showings.ToListAsync());
        }

        // GET: Showings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Showing showing = await _context.Showings
                .Include(s => s.MovieShowings).ThenInclude(s => s.Movie)  
                .FirstOrDefaultAsync(m => m.ShowingID == id);
            if (showing == null)
            {
                return NotFound();
            }

            return View(showing);
        }

        // GET: Showings/Create
        public IActionResult Create()
        {
            ViewBag.AllMovies = GetAllMovies();  
            return View();
        }

        // POST: Showings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("ShowingID,ShowingNumber,Title,Description,Showtime,Price")] Showing showing, int[] SelectedMovies)                                                                                                                              
        {
            showing.ShowingNumber = Utilities.GenerateShowingNumber.GetNextShowingNumber(_context);  

            if (ModelState.IsValid)
            {
                _context.Add(showing);
                _context.SaveChanges();

                //Add navigational data 
                //Find the showing with the same showing number as the one we just created 
                Showing dbShowing = _context.Showings.FirstOrDefault(s => s.ShowingNumber == showing.ShowingNumber);  

                //Loop through the selected showings 
                foreach (int d in SelectedMovies)
                {
                    //Find the movie specified by the int
                    Movie movie = _context.Movies.Find(d);

                    //Create a new instance of the bridge table class 
                    MovieShowing ms = new MovieShowing();
                    ms.Showing = dbShowing;
                    ms.Movie = movie;

                    //Add the new record to the database 
                    _context.MovieShowings.Add(ms);
                    _context.SaveChanges();
                }

                return RedirectToAction(nameof(Index));             
            }

            //Re-populate the ViewBag in case of error 
            ViewBag.AllMovies = GetAllMovies();    
            return View(showing);
        }

        // GET: Showings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Showing showing = await _context.Showings.FindAsync(id);
            if (showing == null)
            {
                return NotFound();
            }
            
            //Populate the ViewBag with the list of Movies 
            //Existing Movies should be highlighted 
            ViewBag.AllMovies = GetAllMovies(showing.ShowingID);
            return View(showing);
        }

        // POST: Showings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ShowingID,ShowingNumber,Title,Description,Showtime,Price")] Showing showing, int[] SelectedMovies)
        {        
            if (ModelState.IsValid)
            {
                Showing dbShowing = _context.Showings
                    .Include(ms => ms.MovieShowings).ThenInclude(ms => ms.Movie)
                    .FirstOrDefault(s => s.ShowingNumber == showing.ShowingNumber);

                //Create a list of departments to remove 
                List<MovieShowing> MoviesToRemove = new List<MovieShowing>();

                //Find movies that should no longer be there 
                foreach (MovieShowing ms in dbShowing.MovieShowings)
                {
                    if (SelectedMovies.Contains(ms.Movie.MovieID) == false) //This movie is not on the list 
                    {
                        MoviesToRemove.Add(ms);
                    }
                }

                //Remove movies that you found in the list above - this has to be 2 separate steps because
                //you can't iterate over a list you are removing things from 
                foreach (MovieShowing ms in MoviesToRemove)
                {
                    _context.MovieShowings.Remove(ms);
                    _context.SaveChanges();
                }

                //Add movies that aren't already there 
                foreach (int q in SelectedMovies)
                {
                    if(dbShowing.MovieShowings.Any(d => d.Movie.MovieID == q) == false) //Movie is not already connected to this Showing
                    {
                        //Create a new instance of the bridge table class 
                        MovieShowing ms = new MovieShowing();
                        ms.Movie = _context.Movies.Find(q);
                        ms.Showing = dbShowing;

                        //Add the new instance to the database 
                        _context.MovieShowings.Add(ms);
                        _context.SaveChanges();
                    }
                }

                //Update the scalar properties 
                dbShowing.Title = showing.Title;
                dbShowing.Description = showing.Description;
                dbShowing.Showtime = showing.Showtime;
                dbShowing.Price = showing.Price;

                //Save changes
                _context.Showings.Update(dbShowing);
                _context.SaveChanges();

                //Return to Showings list page
                return RedirectToAction(nameof(Index));
            }

            //Sad path 
            ViewBag.AllMovies = GetAllMovies(showing.ShowingID);
            return View(showing);
        }


        private bool ShowingExists(int id)
        {
            return _context.Showings.Any(e => e.ShowingID == id);
        }
       

        private MultiSelectList GetAllMovies()
        {
            List<Movie> Movies = _context.Movies.ToList();

            //Create the new multiselectlist; note that MovieID and MovieName are the names of fields on the Movie model class
            MultiSelectList AllMovies = new MultiSelectList(Movies, "MovieID", "Title");
            return AllMovies;
        }


        private MultiSelectList GetAllMovies(int showingID)
        {
            //Make a list of all the movies
            List<Movie> Movies = _context.Movies.ToList();

            //Get the list of movies for this showing 
            List<MovieShowing> movieShowings = _context.MovieShowings.Where(ms => ms.Showing.ShowingID == showingID).ToList();

            //Loop through this list to convert to a list of integers
            List<int> selectedMovies = new List<int>();

            foreach (MovieShowing ms in movieShowings)
            {
                selectedMovies.Add(ms.Movie.MovieID);
            }

            //create the multiselect list with the previously selected departments highlighted
            MultiSelectList AllMovies = new MultiSelectList(Movies, "MovieID", "Title", selectedMovies);

            //return the multiselect list
            return AllMovies;
        }
    }
}
