﻿using System;
namespace sp19team9finalproject.Models
{
    public class MajorDetail
    {
        public Int32 MajorDetailID { get; set; }

        public Major Major { get; set; }

        public Position Position { get; set; }
    }
}
